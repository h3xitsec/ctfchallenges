#include <stdio.h>
#include <unistd.h>

int main() {
    setuid(0);
    setgid(0);

    char flag[256] = {0};
    FILE *fp = fopen("/flag", "r");
    if (!fp || fread(flag, 1, 255, fp) < 0) {
        puts("oh no, can't read flag (please contact admin)");
        return 1;
    }
    fclose(fp);
    puts(flag);
}
