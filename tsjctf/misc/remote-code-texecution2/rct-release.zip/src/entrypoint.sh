#!/bin/bash

# mess up process ids
for _ in $(seq $((RANDOM + 10690))); do
    /bin/true
done

# randomize filename
randomname=$(base64 /dev/urandom | tr -d '+/' | head -c20)
mv /workdir/*.py "/workdir/$randomname.py"

echo "initialization complete"
python3 "/workdir/$randomname.py"
