import asyncio, discord, hashlib, os, pathlib, requests
from aiolimiter import AsyncLimiter
from discord.ext import commands
from discord.commands import slash_command, Option


class TexCog(commands.Cog):
	def __init__(self, bot):
		self.bot = bot
		self.secret = os.urandom(32)
		self.locks = {}
		self.rate_limiters = {}
		self.user_files = {}
		self.assets = {}
		for asset in ('makefile1', 'makefile2', '__document.tex'):
			with open(f'./assets/{asset}', 'rb') as file:
				self.assets[asset] = file.read()

	@staticmethod
	def error_embed(msg, log=''):
		embed = discord.Embed(title='Error', color=0xe74c3c)
		if log:
			log = '```\n' + log.strip()[:1000] + '\n```'
		else:
			log = '(no details)'
		embed.add_field(name=msg, value=log)
		embed.set_footer(
			text='TSJ CTF 2022',
			icon_url='https://cdn.discordapp.com/icons/941281863618687016/81b28289206b720ab00d73208d8b6287.webp')
		return embed

	@staticmethod
	async def invoke_make(dir, makefile, target):
		proc = await asyncio.create_subprocess_exec(
			*f'/usr/bin/sudo -u latex /usr/bin/make -s -C {dir} -f {makefile} {target}'.split(),
			stdin=asyncio.subprocess.DEVNULL, stdout=asyncio.subprocess.PIPE,
			stderr=asyncio.subprocess.DEVNULL, start_new_session=True)

		try:
			stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=10)
		except asyncio.TimeoutError:
			pgid = os.getpgid(proc.pid)
			await asyncio.create_subprocess_shell(f'/usr/bin/sudo /bin/kill -s 9 -- -{pgid}')
			return b'Process timed out\n'
		return stdout

	async def process_file(self, id_, file_url, makefile):
		secret = hashlib.sha256(id_.to_bytes(8, 'big') + self.secret).hexdigest()[:20]
		workdir = pathlib.Path('./sandbox') / f'{secret}_{id_}'
		os.makedirs(workdir, exist_ok=True)
		os.chmod(workdir, mode=0o777)

		filename = file_url.split('/')[-1]
		file_content = requests.get(file_url).content[:1024]
		with open(workdir / filename, 'wb') as file:
			file.write(file_content)
		os.chmod(workdir / filename, mode=0o644)
		with open(workdir / makefile, 'wb') as file:
			file.write(self.assets[makefile])
		os.chmod(workdir / makefile, mode=0o644)
		with open(workdir / '__document.tex', 'wb') as file:
			file.write(self.assets['__document.tex'].replace(b'FILENAME', filename.encode()))
		os.chmod(workdir / '__document.tex', mode=0o644)
		(workdir / 'output.png').unlink(missing_ok=True)

		log = b''
		log += await self.invoke_make(workdir, makefile, 'stage1')
		log += await self.invoke_make(workdir, makefile, 'stage2')

		if (workdir / 'output.png').is_file():
			if b'\\' in file_content:
				return self.error_embed('The bot thinks your file is insecure', 'backslash detected!'), None
			else:
				result = discord.Embed(title='', color=0x2ab748)
				result.add_field(name='Compilation success', value='Compilation success')
				result.set_footer(
					text='TSJ CTF 2022',
					icon_url='https://cdn.discordapp.com/icons/941281863618687016/81b28289206b720ab00d73208d8b6287.webp')
				image = discord.File(workdir / 'output.png')
				return result, image
		else:
			return self.error_embed('Compilation failed', log.decode('utf-8')), None

	@commands.Cog.listener()
	async def on_message(self, message):
		if message.guild != None:
			return
		if len(message.attachments) != 1 or not message.attachments[0].filename.endswith('.tex'):
			return

		async def upload_callback(interaction):
			url = self.user_files[message.author] = message.attachments[0].url
			await interaction.response.send_message(f'Your file is set to `{url}`')
			await reply_msg.delete()

		async def cancel_callback(interaction):
			await interaction.response.send_message('Your file is unchanged.')
			await reply_msg.delete()

		upload_btn = discord.ui.Button(label='Yes', style=discord.ButtonStyle.primary, row=0)
		upload_btn.callback = upload_callback
		cancel_btn = discord.ui.Button(label='No', style=discord.ButtonStyle.secondary, row=0)
		cancel_btn.callback = cancel_callback

		view = discord.ui.View(timeout=300)
		view.add_item(upload_btn)
		view.add_item(cancel_btn)
		reply_msg = await message.reply('`.tex` file detected. Upload this file?', view=view)

	@slash_command(name='upload', description='Upload a TeX file to the bot')
	async def upload_tex(
		self,
		ctx: discord.ApplicationContext,
		file: Option(discord.Attachment, 'Your TeX file', required=True)
	):
		if file.url.endswith('.tex'):
			url = self.user_files[ctx.interaction.user] = file.url
			await ctx.respond(f'Your file is set to `{url}`', ephemeral=True)
		else:
			await ctx.respond(embed=self.error_embed('Not a .tex file'), ephemeral=True)

	@slash_command(name='render', description='Render the uploaded file')
	async def render_tex(self, ctx: discord.ApplicationContext):
		if ctx.user not in self.user_files:
			await ctx.respond(embed=self.error_embed('No file uploaded'), ephemeral=True)
			return

		async def work(interaction):
			limiter = self.rate_limiters.get(interaction.user)
			if limiter == None:
				limiter = self.rate_limiters[interaction.user] = AsyncLimiter(15, 600)

			if limiter.has_capacity():
				await limiter.acquire()
			else:
				await interaction.response.send_message('You are being rate limited.', ephemeral=True)
				return

			lock = self.locks.get(interaction.user)
			if lock == None:
				lock = self.locks[interaction.user] = asyncio.Lock()

			async with lock:
				await interaction.response.send_message('Compiling...', ephemeral=True)
				try:
					makefile = 'makefile1' if select.values[0] == 'w' else 'makefile2'
					result, image = await self.process_file(ctx.user.id, self.user_files[ctx.user], makefile)
					if image:
						await interaction.edit_original_message(content='', embed=result, file=image)
					else:
						await interaction.edit_original_message(content='', embed=result)
				except:
					await interaction.edit_original_message(content='', embed=self.error_embed('Unexpected error'))
					raise

		select = discord.ui.Select(placeholder='Select an option')
		select.add_option(label='White Background', value='w')
		select.add_option(label='White Text', value='t')
		select.callback = work

		view = discord.ui.View(timeout=300)
		view.add_item(select)
		await ctx.respond('Select an output format', view=view, ephemeral=True)

if __name__ == '__main__':
	bot = discord.Bot()
	bot.add_cog(TexCog(bot))
	bot.run(os.environ['DISCORD_TOKEN'])

# the flag will be here on the server (you still have to leak the source)
# here is your flag 1: T5J{not_this}
