`docker build -t microservice .`
`docker run -p 3001:3001 microservice`