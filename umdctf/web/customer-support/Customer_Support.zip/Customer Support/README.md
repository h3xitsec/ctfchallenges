# Customer Support

## Build and run 
`docker build -t customer-support .`
`docker run -p 3000:3000 customer-support`

open: http://localhost:3000